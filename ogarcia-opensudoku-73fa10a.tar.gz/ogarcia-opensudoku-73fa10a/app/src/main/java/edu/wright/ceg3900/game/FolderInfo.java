/* 
 * Copyright (C) 2009 Roman Masek
 * 
 * This file is part of OpenSudoku.
 * 
 * OpenSudoku is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * OpenSudoku is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with OpenSudoku.  If not, see <http://www.gnu.org/licenses/>.
 * Copyright 2017 Matt Anderson

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */

package edu.wright.ceg3900.game;

import edu.wright.ceg3900.R;
import android.content.Context;

/**
 * Some information about folder, used in FolderListActivity.
 *
 * @author romario
 */
public class FolderInfo {

	/**
	 * Primary key of folder.
	 */
	public long id;

	/**
	 * Name of the folder.
	 */
	public String name;

	/**
	 * Total count of puzzles in the folder.
	 */
	public int puzzleCount;

	/**
	 * Count of solved puzzles in the folder.
	 */
	public int solvedCount;

	/**
	 * Count of puzzles in "playing" state in the folder.
	 */
	public int playingCount;

	public FolderInfo() {

	}

	public FolderInfo(long id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getDetail(Context c) {
		StringBuilder sb = new StringBuilder();

		if (puzzleCount == 0) {
			// no puzzles in folder
			sb.append(c.getString(R.string.no_puzzles));
		} else {
			// there are some puzzles
			sb.append(puzzleCount == 1 ? c.getString(R.string.one_puzzle) : c.getString(R.string.n_puzzles, puzzleCount));

			int unsolvedCount = puzzleCount - solvedCount;

			// if there are any playing or unsolved puzzles, add info about them
			if (playingCount != 0 || unsolvedCount != 0) {
				sb.append(" (");

				if (playingCount != 0) {
					sb.append(c.getString(R.string.n_playing, playingCount));
					if (unsolvedCount != 0) {
						sb.append(", ");
					}
				}

				if (unsolvedCount != 0) {
					sb.append(c.getString(R.string.n_unsolved, unsolvedCount));
				}

				sb.append(")");
			}

			// maybe all puzzles are solved?
			if (unsolvedCount == 0 && puzzleCount != 0) {
				sb.append(" (").append(c.getString(R.string.all_solved)).append(")");
			}

		}

		return sb.toString();

	}

}
